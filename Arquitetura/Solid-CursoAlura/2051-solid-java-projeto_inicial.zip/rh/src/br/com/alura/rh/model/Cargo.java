package br.com.alura.rh.model;

public enum Cargo {

	ASSISTENTE,
	ANALISTA,
	ESPECIALISTA,
	GERENTE;

}
