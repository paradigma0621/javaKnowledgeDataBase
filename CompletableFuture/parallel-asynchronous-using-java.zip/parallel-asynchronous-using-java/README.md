![parallel-asynchronous-using-java](https://github.com/dilipsundarraj1/parallel-asynchronous-using-java/workflows/parallel-asyncronous/badge.svg)

# parallel-asyncronous
This repo has the code for parallel and asynchronous programming in Java

## Swagger-UI

-   Click on the following [link](http://localhost:8080/movies/swagger-ui.html) for swagger.